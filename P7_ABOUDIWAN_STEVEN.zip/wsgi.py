import sys

sys.path.insert(0, '08_WEBSITE_AND_MODELS')

from flask_back import app

if __name__ == "__main__":
    app.run(debug=True)
