"""
The purpose of this python file is to regroup every functions from the external kernel
"""
import streamlit as st


def custom_simu_page_front():
    st.write("Incomming in a future update")
